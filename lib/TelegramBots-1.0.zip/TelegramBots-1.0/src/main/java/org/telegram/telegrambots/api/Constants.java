package org.telegram.telegrambots.api;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * @brief TODO
 * @date 20 of June of 2015
 */
public class Constants {
    public static final String BASEURL = "https://api.telegram.org/bot";
}
